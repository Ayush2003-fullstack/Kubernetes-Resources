# Day 35/40 - Kubernetes ETCD Backup And Restore Explained

## Check out the video below for Day35 👇

[![Day 35/40 - Kubernetes ETCD Backup And Restore Explained](https://img.youtube.com/vi/R2wuFCYgnm4/sddefault.jpg)](https://youtu.be/R2wuFCYgnm4)
