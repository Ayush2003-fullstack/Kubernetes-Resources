# Day 40/40 - JSONPath Tutorial - Advanced Kubectl Commands

## Check out the video below for Day40 👇

[![Day 40/40 - JSONPath Tutorial - Advanced Kubectl Commands](https://img.youtube.com/vi/l9_UDSaiFj4/sddefault.jpg)](https://youtu.be/l9_UDSaiFj4)

## Task for the video
Hands-on task details have been provided in [this file](https://github.com/piyushsachdeva/CKA-2024/blob/main/Resources/Day40/task.md)

