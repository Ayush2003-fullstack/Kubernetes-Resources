# Day 28/40 - Docker Volume Explained - Docker Bind Mount - Docker Persistent Storage

## Check out the video below for Day27 👇

[![Day 28/40 - Docker Volume Explained - Docker Bind Mount - Docker Persistent Storage ](https://img.youtube.com/vi/ZAPX21TMkkQ/sddefault.jpg)](https://youtu.be/ZAPX21TMkkQ)


### Docker layered architecture

![image](https://github.com/user-attachments/assets/a1f16123-f868-4ee6-a872-7af521427ebf)
