# DDay 38/40 - Troubleshooting control plane failure in Kubernetes

## Check out the video below for Day38 👇

[![Day 38/40 - Troubleshooting control plane failure in kubernetes](https://img.youtube.com/vi/z6XjbuRl6LE/sddefault.jpg)](https://youtu.be/z6XjbuRl6LE)

## Task for the video
Hands-on task details have been provided in [this file](https://github.com/piyushsachdeva/CKA-2024/blob/main/Resources/Day38/task.md)
