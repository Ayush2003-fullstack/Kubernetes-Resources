# Day 39/40 - Troubleshooting Worker Nodes Failures in Kubernetes

## Check out the video below for Day39 👇

[![Day 39/40 - Troubleshooting Worker Nodes Failures in Kubernetes](https://img.youtube.com/vi/U6PRwv7dJ-U/sddefault.jpg)](https://youtu.be/U6PRwv7dJ-U)

## Task for the video
Hands-on task details have been provided in [this file](https://github.com/piyushsachdeva/CKA-2024/blob/main/Resources/Day39/task.md)
