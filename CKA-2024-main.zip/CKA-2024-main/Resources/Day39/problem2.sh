#!/usr/bin/env bash


# Stop kubelet 
sudo systemctl stop kubelet
