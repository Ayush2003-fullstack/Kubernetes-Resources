# Day 20/40 - SSL/TLS Explained Simply

## Check out the video below for Day20 👇

[![Day 20/40 - SSL/TLS Explained Simply](https://img.youtube.com/vi/njT5ECuwCTo/sddefault.jpg)](https://youtu.be/njT5ECuwCTo)

