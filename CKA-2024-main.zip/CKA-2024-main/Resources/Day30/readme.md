# Day 30/40 - What Is DNS ( Domain Name System) 

## Check out the video below for Day30 👇

[![Day 30/40 - What Is DNS ( Domain Name System) ](https://img.youtube.com/vi/fDOoB4k4YSs/sddefault.jpg)](https://youtu.be/fDOoB4k4YSs)

