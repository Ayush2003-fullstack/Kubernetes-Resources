Check out the task.md file for hands-on practice.
