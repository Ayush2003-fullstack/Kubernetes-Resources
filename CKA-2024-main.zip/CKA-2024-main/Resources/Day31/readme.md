# Day 31/40 - Understanding CoreDNS In Kubernetes

## Check out the video below for Day31 👇

[![Day 31/40 - Understanding CoreDNS In Kubernetes ](https://img.youtube.com/vi/VcWpZoRAQXE/sddefault.jpg)](https://youtu.be/VcWpZoRAQXE)
