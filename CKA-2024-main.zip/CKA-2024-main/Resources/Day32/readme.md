# Day 32/40 - Kubernetes Networking Explained | Container Network Interface (CNI) 

## Check out the video below for Day32 👇

[![Day 32/40 - Kubernetes Networking Explained | Container Network Interface (CNI)](https://img.youtube.com/vi/EkAzMGldC5M/sddefault.jpg)](https://youtu.be/EkAzMGldC5M)


### Find more useful resource here:
https://github.com/saiyam1814/kube-networking
